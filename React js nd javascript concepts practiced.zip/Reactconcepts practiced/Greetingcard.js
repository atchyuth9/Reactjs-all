import React, { Fragment } from "react";

class Greetingcard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "hello"
    };
  }
  sayGoodmrg = () => {
    this.setState({
      message: "Good Morning prends"
    });
  };
  sayGdafn = () => {
    this.setState({
      message: "gd afn prends"
    });
  };
  sayGdevg = (value) => {
    this.setState({
      message: value
    });
  };

  render() {
    return (
      <Fragment>
        <div className="card">
          <div className="card-body">
            <p className="h3">{this.state.message}</p>
            <button onClick={this.sayGoodmrg} className="btn">
              goodmrg
            </button>
            <button onClick={this.sayGdafn} className="btn1">
              goodevng
            </button>
            <button
              onClick={this.sayGdevg.bind(this, "gdboy")}
              className="btn2"
            >
              goodnight
            </button>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Greetingcard;
