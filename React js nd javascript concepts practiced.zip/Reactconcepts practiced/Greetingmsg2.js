import React, { Fragment } from "react";

class Greetingmsg2 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "helo"
    };
  }

  //update msg
  updateMsg = (value) => {
    this.setState({
      message: value
    });
  };
  render() {
    return (
      <Fragment>
        <div className="card">
          <div className="card-body">
            <p className="h3">hi prends</p>
            <button onClick={this.updateMsg.bind(this, "poo")} className="btn">
              good mrng dosts
            </button>
            <button
              onClick={this.updateMsg.bind(this, "itslunchtime")}
              className="btn1"
            >
              good afternoon
            </button>
            <button
              onClick={this.updateMsg.bind(this, "nak nidrostundi nenpotha")}
              className="btn2"
            >
              good evng nd night
            </button>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Greetingmsg2;
