import React, { Fragment } from "react";

class ProductItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      Products: {
        sno: 101,
        image:
          "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFRgWFhYZGRgaGhocHRkaGhwcHBwdGhgcGhoeGB4eIS4lHh4rIRoaJjgmKy8xNTU1GiQ7QD00Py40NTEBDAwMEA8QHhISHzQrJSs0NDQ0NDQ0NDQ0NDQ0NDQ9NDQ0NDQ0NDQ0NDQ0NDQ1NDQ0NDQ0NDQxNDQ0NDQ0NDQ0Nv/AABEIAL4BCQMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBQECBAAGB//EAEMQAAECAwYDBAkDAwIEBwEAAAECEQAhMQMEEkFRYQVxgSJCUpETMmKSobHB0fAGFHKC4fHC0hUjorIWNFNjc+LyB//EABoBAAMBAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAoEQACAgICAgECBwEAAAAAAAAAAQIRAyESMQRBEwVRIiMyYXGBkUL/2gAMAwEAAhEDEQA/APPXy+KcKQo4hkM45C7ytQI7POPSXXgyAQCpI6iHNjwyyQHUtPvCOFyXpHSqPO2N1tVjtOTDG7cAWszh0vid2skgFaCWyUITX79YIPqGe0Tyk9JCrFF3Jo3J4OizDrnF7O0skAsJ6R5m04+VVJjrvfkqooGJkp+0a48uGWotM9J/xLDRPKPG/qO9FdsVHQQ59K4jz/Gg9o+0Vg/Ucn1Nfk/2hPb8PJPpBnlG7h1sU9ky5xrsCCgco12F1CqiK59qQ8eGThHg60nXow290tFl3DR1nw5YUD2ZR6y4cHSuohgr9MpHiPUxazpHVHP5UFxikeLNxWoTIEXRwymJbjSPaWX6asUzWpX8cRjRZ8Gu7gBD8yfvD+aJkp+U29JWeFt+HJVmANoGvhdAFGPoF5ul0sh2kJfSMltxWwsh2EAnkIXzJKkhSx5siqTVHilfp5ZmAvyMAPB1pkSqPR3njq1ktIaCF9pfFGJ+Z/YcfFjHa7/gUK4cod4gcoPYgJ73nGpVuTAlMqRh/P8AdClhzXcWv8KKt0eKMq7+gUnBLjwtK1KJWwnGa8cNSAS5JJkBA88aM78tukkv3M9vxbwiMh4pamSflD7hP6VXakDDhGprHsbHgd1ubKIxrGapz2FIl5r6RpDBlu5zf9HiOG8Avl4momzRmpQaWwhwnhN3u4IUTar8SsuQoI3cR4ytcgWGghQvUmM5Tb7OjjFerK2hTUgAQo4rfQ2FMX4nfu6KwhtbTMw4xsynKtGVaylTiREe0/TnHk2icC0soCuseJtbbaGfAb2lJwkMSaxrkhcOtnKpKMrR9FFogjKM1vZIVzhWuyUJgwMrWI4uJtzTNVpYNSYgEVTeFZxX00PZPGIxtP0veRPADyV92jNeOA3lID2SyNp/Ix7Lja1h14uxkA4PWEt2/UK0FsTuc5x1LK/siJfS4epP/TzK+EWn/pL90xmXdLRJ9QjmGj6tYW6bQJWgO47TUBhFeUutlhi+ecP5n9iF9Liu5NnllcNtjZFeDs0rPyhGtRSZgpPlH0fj9qmyshZpzrHlb1gKWUARvWI+Z+yn9MhFfgbTFV243aJkS43g954gm2UCmRahhPfbEAkoppGJNoQY0hV8kc2aOXi8cno9nw2zKhSPUcLugaceW/RF89JaeiVUh0nlV4+j3a4lMY5H+JnreK/yVfdDHht0SlMhXWNa0tUsIzpThFTCDjduuQ7TRNmlNseqKBNwYWcR4owIQB9YS3W0W83hmu7hSXzgspRR5m9rWouomIXdVSkZwxvdiAaR7O7XNKkIJ8I+UUnYSaifPrDhC1ySk+Ubbt+mbRVQAN49ooIRQQM8QSnQczBQr+yPO/8AhAs+N+QhFf8AhZsiyo91ev1BY2aS9okq0EeJ4txUWqsWKE4MqMZNbRXhXDU2qlIKmlKGV0uaEW2BYDgSOvKFV0vAStC0nMUj0XGrBl2NqDMljyMRQtrQ9sQhKQpmIePC8av5WstrHoP1FesFklL9pRePILWEupUNsldEYQA6oTcR4hUJgXEOIlUk0hJeLyE84qEG2Yzmki1vbZkwuXaFRlFSoqMaEWUdaSgjinkBWaIOlDTEHsbspVBDK78KPeppGcsiRjUpDvhdoVWaSdIMoRW6skBOkFVHK3ezWNrQEpiuGCKiMMIux7fePY0sQAcx9oR2tuklwGArGL0ySJloCviAFJxrddHpWeguHFDZkKQ45GR6Q8/4pdrVJNo6VtVnHTSPmyr6p5FhA7biBAmqFxb6FyPXfqLiNmogoLsG0fSUeVt7wVEkmE9rxHSM/p1KMaRwPtkudukNLa9JGcK7e3cuBEmxJglndo2jGMRvx5T00es//md8KLzhIlaDC7UIcj6x9q9C7GPhfBruuzUlYOEiYj1w/Ud5b1/gIznjcpWdMfDkopJo+mBEL+KWALCPndpx68E+ufhALTi1sqq1GD4Wy4+DO7tHvbtcz3QI2nhz+soAR81HGLcUtFDygNrxG2V61oo9YcfGftmq+nzftH0m1srszKWkHV4X379UWNkMKVFbSAT94+cms5xZYjWPjxT2bR+nRT/E2x7f/wBV2q3CAEDzMI1Wq1l1KJ5mLWdmTlGyzuavDFvjFUjaXxYVSSQCzTs8FTYgwwsuHym0zKLiyCX2jnlkRwZM1vQuTciGKS0Ml8UWLNKFomk+u70jIu/JAmf8xkteMjKMXJN7RhyV2xpxK/Y0+kWZgSEeR4nfirOUB4nxcqqW2hHa2yllhIRcYcnfSOXNmgroLeL08kxnTZEzMarrcyosA5h5duDZq8otzjDSPNlKUnoRWF3JLAOYeXLhGa/KGdhc0oZg0bwkM8YyyNiUUuzLZXZKRINBQgRcmKGM6LTOKBFhMQMxAVC6G9krS0UaDhbiKejgJtnj7e+7xkXxDQQBF0JjbYcIUqbGO5Qgj1Y4csukY1XxRgeBStY9HdOAkmgjcngpTJqbRapdHRDwb/XI8vd+HFUMkXIIDNMw7F3SidWgVkkLJUYG0dcMWLFpLf3MKOHjN402V2SlpRrCWziFLTFJI64pekEQuDeljIDOLqMUoo0UF7LlccFQEZQVMVxRfFI5So5MWSh43Xfh5U0vpEuSRE8sILZi9G8b7tw5S5gShvduHAPTlvlkzRNrehZzYAs7JpKoORjCeb7Hn5fLb1Em7XBKPWmcopfbwhAxMAJOMtKQrvXGKtzBhJfOIqVN45pSbezhnNt3Jjq8caAkA4DnllCS88SKn3hPeL8zzjEq8qV6o84pY2znnnjFDK3veplC28X8mSfOOsbmpZm6jtSGt34Go5ARX4Id7OOfkuWoiNFgSXUXhxw/hKlzonXXlDa7cFSmai/yhzZoAEvzlEzyt9HPTbuRmulxSgAAddY0lEWf8/M47F+fmcYFA12ZgYQRBlK/NIoVw0BUoipTBErbl9Y5aYYICRHN+bxB/wAfUxH4PvElo4j81MdiMcx+33irDUwFaC2XC7MNhro3OhNWgybqEh2A31/vKAKvg1xdG89Y793pLpHoUz6TjI1+kaagFEdOTEVMZ7S9MDhesy/0jPa2j1gWB84KodV2VtLeQFXjVZCyAYp+cCXclg4imWTEGQ0aONnOsEUmVCKluwqzZiiYApacktEFI1iqyI1SOiKX7kKVFAgmUaLGzxGUNLrw4uxDH8eBz4hPOoIW3a5kwysOGScg6tt56awzwJSnsgYhnlRpj8pFrS/JQHVXMD4/GMJ5mcGTy5S6BouiE5TrV5CuE6we1tkIKZ5OBPOYpIwkv3F59mTGRl/mE9pfzOZOg+TfmUc8ptnLKbl2x3e+LgY8NCTPCQfLOEl7vzgB99BSF14vuETNM/pCq8X1Sj2R1P0hxg5HNPNGKGN4voSJnKE94v6lFkjrHC6lRdUzG663LtABJJNI0ShD92cU/Jb6Ml2uRUQ7kmPWcM/TkgV+6MuZhpwTg6UDEoOv5bDSHBSB+VjOeRyOZtt2xbd7ghEkpAB+MXVZN+VjSpQ15nTaOW2R5bD81jIroxlH59BEYfzT+8aCB9vvFSB9tzr/AIiSrAN+abmOwf2+5gxbV9dzpFevP7QDAlJy6fcxUp/NTrBzz57D6RU/OmwgBMBg/NTFkBpZUH1iS30H3/zEy+g+sOwKKR8flAlJ+PyjSWI+A5CsCUB5/IQMYH6/ARHZ/Hi5+cun0juzp8IQ7E4sSILZqarQxtrgWd6/CMVpdW3j1OSfZ9ZHKpdlsW8Dxs24zFYNZXGmIhzQRoVcFu+EkGlD5Rnpszk4yemZ0LYaDSJxFoKLisn1fzPaNdhww5lswS7Fqv5jzi7ijXlCC7MCLAqIEMbrwx1TDSjbd7JCTNutd9jz+EBteJhGLCJZF05ZuDMc4zll+xy5PJf/ACarKzQh3FM5tL4RivHEkuRSYIBaT/TzkYU3jiKmJpMkJcZ701lC1d4YDqPOgycSjCUmzinkvbY6tuLqNJZET/P7Qttr07uc/wArCtd6ab/IDPaF144jXDM65QljlJ6MJZUhteb5KrCFlrfyT2JnXKMlmhSz2i/yhndrsE8/lGnGMO9s5Z52+gFjdCo4lF9o9FwrgIX2l9lA0qftzg/COFlTLWJd1OZ9rYc49LZpAEqCnP2hpvGbm5HHOZms+EoSOwkA7zb7xVFjgJOGeufXQQzu1rhUDhxAd2uI6p/zDq83ezt0MkYVNmMJGygRQzGcZyRWJOUTzdjeNW50A2c5xJW9G22GpH1hiOGISiZm1AAQktn1gKLOwSgApBXI6fgibKeGTd9GBY/tufqIoi0FCef2EMEJsg3YKzoAyTGdd1WouE4QTLQbQ7RPxyqjMq1TrM/AbQJVsKgnSlP7xs/Zreg05co5V3WmqRoGLtzzfzhWg+Oa9GBVsBkZbZ6mKm3bJUpmWe+gjUojLkBKuZ0f4wIqTWTCu6t9PjBQrA+mNMJnM5eWkR6ZR7tdxTaCqIoW1V9NvOcRjfmqQkZDXXrSGVaAqtFVw7Cfy1PnFVLUMqb5/eDFYExQSGbltvW6NEYxR6TJ30Jy5RIuSBC0VpNtac4ha1aAS1pF8WWZmZMwH/aN6xItMX9RlyGn3rFFWBUVbCXkPvAO1oPIxsKnlqfgNNOdY7EnQ+SoAC3i9ByXEssh+NC9V7GQc6/aF6ELVSkPeH8EoVuHoddhvKO5pI+qcYwW2Z7KzUQVES+PSGl1KiACZUmOv2g9vgSGkQJB2DUqZEZ1Bz1ga+IoSD2RnQ0HNgH3/vGbkkjmlNG5SAiZl0nLTScm+cYL/fEBsOVCAGenIj80ZXeeJqW4dho/2+8KLa9fmfnGTkzCUzdfuIKWKs1WqOVWbWULl3ghLZ6E+dBGG3vU/wA/v+CFtvf2pMxcYSkc88qQxtb15DfSF1vfw8pn4fk4xlSlVMtINZXWNVCMezknnBkqVU9Mo02V1lGixsAKBzDe68HtFByMKdVV6DWJlk9I5ZZbMFhZUAHTWPR8L4PPFaZMcP8AuEMOH8MRZhxNWajkP9J5QwQlmboM+ehHJzGDtmTmchOUuWQHs5A82giHJEzOQYOQMyRnziCzbfBStvCeZglhaFCnzzOY0GWIyq8KtERaclY2u10SguFHtCYPN55vKsabRb0E2ylyaFq70dW1rLmDn5xltLwp671pORMZ1Z6POMVUTfaE4nUZZkTJGih94GVJUXSgJkZlIPweF5C1OHNaP8Vbxpu61OkEJLFw/ZMszKn3hVRKk5GxNmGA6vIBhkCOsolNmAQQwajamjtk/wA4n0jvJyRJ8ueWfygWIuRk4Sxl5fhgNUkabJWOuELSA4HqncgzaUQlcpiYkxqD0yjOi1JUjtGoBmlmVIu82cgyi9urCokD1g/I0dX5lEstOhLxZBCyrEklQZgGw1fFtC557JoBUlqo25vD7iY7FATXFUjcDOWUeeWmoIkJkPJ9SddpRcdo4syqWiSZNKZcnu1p/LyiqlmZzMmzA1VqPOIcy1Xm02GTZDecVJZzkmSdj7PiMMzTJfyAlTtH2ckxDmj1mTps1TzMTgyP8lVY/wAj3eUUJNczIageyPDvKChpkqNTLQB5c312lHYmf2RnmWqvSOZiaMn3X29rziAigNaqeo3VkeUAWWxNN8nnnufZjsW/yigmP5KluBmdOU4Jj9o+4ftDDv2NbG7psgWE5aBn0xV5bQLiXGEpRgSQJADfYuM+jQsv3EXIDAgAzIDg5dGhPaXl1VlnSRjZys+gnO3bGFreyZFyCJPPp9mEYV3ljvrm3z67xhvF7qxl9XrC+8X0a9BAouRzzypDK8XycoWW9+Azc6RjNopWw2gtldNY1UIx/Ucc/IArUpfLQQexuesM7jwxa/VSwzUZAR6C5cDSn1+0dKAb+1Clk9I455mzzt1uClFkpJ5feHVz4BQrNaJTnu/0h/Z2IAAADZASBOo0bQPBWrm9faO3L6UjJybMHIyXW4oQOykAa5qOjmafONbf39nmNdw3OJHPmcm02PlHNSXIZjdWo6HnATbLoMgz7DM7nIjziQeozPiOmqYqjPMf938S9OvSLGpnPM0KRpNniiCz+eumycieflEJ0AplXDuRry8ojbyGQGqhl5ARGgYnQGqjqk6dAIQwwtCRqMncjmrMflIlF4AqHFBmCfi0AJd9qnPluOTCIJzkHk/dA3qAdhC4plLJKL0zbZ3pLkqk1dOhyO1YIm0xF0FxQpM6mrGZ5wqWrJiwoMzuk5dDGULIMjNRrQclGr/GIlFG0M0q2eg9GC4wpJoajSTj5Ry0hjMpcNMOkH78zpCT92tD4VEJGs57DPrODI4ooJKVIdRejPPPQDaIcX6OmOZNbGSLNRUhwClJxPSeFuyXdNaRrtVOXeQDasTMjV5CFyL4hTYFTeYyMpvy2jQi0wgu2IhyCcLtmD+ZCJp3RqpKrRn4qsBDsQdUnPcU6kNCTDQS8R0/pzJ5Sg99twtTsQEimYO505RmBcN4plv9GT85xolSOLJNSlaOJqrMyeVPbyjiJjRNNTLuZtFivvaSBnL+WZMUKaJbcjXr3R5QyUypEsplych/L2ugiVVdjRgH7R3B02nEFfezMknQbDPnOIbutITIeT6lX0MIZIFB5lpcsOR3IEQpWbTNA9BqDmdnihJrN1Zt2m2GQ3Ec88mT7r7e15wDJJaeg0qdVivwgfpT4keaYnCZBpkuQa81beUT6T2keR+8Owo86u9BiQJkdfjGO2voAZw+0L1W6lGQ/PpBrC6VKo6ljS2z0J56VlV2illgGEFsbkM5w2ufDVLywpFT/aHtz4alDFsSsnpzGsTLLWkccsspCW5cIWtmGEVnKWu8O7pwqzQHIxe0dfZGfURtCA1ZPXMHT2YKk5tPw6jU+LpGLbZg2y6UTAYOKJybUigPIxcM2zy1J03HNoGKM8n9bwnQDu8zEl9Jmo219owEVYR6v/UdNkn6U3iSZ6a+yNRodg8UGWbSHtbE/SLDmwGdGOnsiFYFk5S5BvW3IeXM+Uc9ZyzVv4XzD6NEAZNWZGm6Q8+cTiz6AvI/zOu0ABbEFyGm3q0AGsqfExDhnDkCniB1LUG5DxFlVj11T/AZDecco0MnMkmo65k7mUNPQmtkvuJ1UPVVto+5ipPmaJNG1S8ieoEdKdGHrTko7qFeTRBPmeikj5AeUKx0SoisyE+8D7W2wMVLv7RqdR809R1iMQcF5CSSBU7Jz5iK1lmZqDyHNVQdpwrDiQpQZ27IonJ9U5KMAtQXaqlZkOW0aiflB1rHrOWok97lo3OM9rJ095UyBINqTkeT8oGy4o5bSOQk+ZOiyaDZmgOW/kEcyXl0aCIZXZDFKZkCSTzNH2Mo5IMlaySSJDbD9ZwrG1RCUkFg4CZlpMRQoFfpF8aicRLkyGp+iT16RcWPd0maP0NAPKObvayGnUVVznDJtrRFpZgsMhPUg9PWPTrAWzzVKsm3Pd5OY0IE8BoJu/wBbs8pRVYzzNNW2GfMw2TVaBkMf4iVAT/EUI3aBrBpJzWrdRUnyghajjCK1IffMnrA1ks/eNOWyqJ5QFpFVGZOgYTmf6qAbEmKtIDWZlLonM7hospnbITpU8u/zlAyqROZ/Jnu8nhFUSpQmdJCfzVUcoq1BmZmXyFDznElnAyGwr7OSubRRSpHU5Zt7f8AaAP5OKqnISGg5moOwYRDnxHy/wDtHEhxoM8n9nfnE/uD/wC5/wBMA+Kfs8hd7DJInHoblw5AsypTFRWkDYMSZeU4i73UJkBDUJAskBpqWS+wADDz+Edk1SOV+S5tpdBE2bD5Dxbj+8FCJkAzFVfQ6dIqSX9r/T7Uc4kO7lz2GcchuWeT93SczqPFFgkuz9rXbRu7EBZq3a02/wBMSGZn7NSd9z3oViokGpyzD+sf5d7lF2NHmzvoND4YoFF3zHqjXplziX1o7nY7HPlDJLJybP1RpunXVzF/i3/UdRqecoqFEk+I/L2tOkWCqEck679OcAzsNQ/NX0Vr0jp1afdTtqnw9REA7SFRvqkVHOLT1Dmh0GijnCYJEoDGsu8rI7KOfSLrSXLCZyOnORSICohtk1E35pFRPOD2poc1UVRh7RFeUCY5R6BlpF+wKHN6dlvmY4jJ2UrPJt8lGIJY6HoCv6NFcWWtQ3qjZOZgYkSWnoKpaZOuHIRU0E60VkjbFUmKk5P2U0Ob7mqYgKNZYlS2bbJR5wimi/ezkKZr+jQJQDazpkjfX5RYp7s8ImfE+4yHKIfvSeiT3fOvnACdMGizBITUAYioyHNIFflGsIDY+gObe1kkeUZVjCRkSXJNeaQJRrKqq0kCGPVVHO0CHN7TO9EGAyqTPCeWb8zAzKedAHYt/LPlFyC7UJmo/wC6jchFF+LonQ8hlzhkqgakUSOZLTr4NN5xZSgQVy0AM09TOe0oGpPczMz/AJ73xiUqDvQCQLZ/xy5yhJl8U0DUmYTN6nxf0mgEVK6qloJU6d49TErQwbxVn2epr0eKqM85CXi/o2gBFFCiAKzO/M93yiptJlUmTITkORorzjlUOpPQfzDT8oGR6oeQzy/o0PWEWjnYAZqrqend8jHFU6Bk5ZJ60J5tFcXrKn5DF/UKNzipTIJk5m3dE6g1+cAUdjk+au80zs31Dx37ceAe8r7RzuSXkkNiafJs/KA+mG/uj/dFCqPssDG20IwWQbxEzrP4RhChG21tAVIEg1mHbdyTHblejy8K2/6DNuZZ67DaJfyOWnM5RR0ymPZnXrFg2Rcmu3SOI9Jlwk0fta7fWLA593TfbSBykMTAULzPXKLOKvPR/nrAS0E5mZodOavpHDrKuqumkVSzSNa7chlEhQlMS9WcvOGTRLSrXPw7CLv8cttTqYGCmc/5a7dIsFDUOaHbQaQmNImXQUL1O5y5ROLk5qNB7Iz5xTGmuQy0Ou8c+T9o56jT2YGNIuGlOQoXnyUcoK/ZBkFGTaAHId47wDGmvdFRk+r5wVCxhr2iZKagOQGUJdlNWisqdwVGb+1HFWbhzJJaTbDKKlQppUZHmdecd6QV1kPEP47QEpHEOcOk1DXmqISrvZUEvV5DPnElvV0mT/v1jsc8XQaHkISG9FsHdzqTqPaNREA0LUkBkf4/4iwMsIacyCXAferxBW86gUHe/sIokpaINA+I1n2hzNIJd1hpFgnMTBPWpiilSq518P1MDs1MWxDDmSzE8qAxPTL48omhbivZJqcgN8niqiJmgDtod1ESiCpnLhJMgCWHPQmIk4TTMg97mRFGaBLlLNWtP6MooSMQE2TkD2up05QRax2j0/8AwYAohsOsyHDj+Rz6xLNYhFLDFThzIZpHNpvzgCwGCdZkZq5Gg+EFs7QEs4LUPdH9/OArtGBOsmeZ/iawBVEFQcnw0Hhlnr5wJSgBuqqjQ8tOsWUodlPVnDj+WREQLQFRLiQqT2emh84RaRVYDgTAA/r/AMcooSJmWyX7J3J18onGAkqch8y2LpqPKKLaSZAHJ/W5mvnDGcaCc8zmkbCpEX7PjPw+0Cxgqy7NE+Hdnn5wP9z7afIwbCkffOCXVBu9gShL+is+6PANo3ftUeBPuj7QDgf/AJaw/wDis/8AsTG6PUNqQH9sjwJ90faO/bI8CfdH2g8dCoYD9sjwJ90faO/ao8CfdH2g8dBQAP2yPAn3R9o79sjwJ90faDR0FBQH9qjwJ90faO/bI8CfdEHiIKAUW9+sEqSCEsVqSVYQySlKlFy3snlnE2/ELugpHZJWWGFGKgWXLCn/AC1jmIvbcFs1lZUVHE7zYAKQUlgBoozM6TkIrZ8Cs0qCgVOFYh2pCdocIl6v/NtN+1WQZ0BWz4jdlJCnQAUhTKSxALM4asxLcRKr9dwU+r2lKTiwyBQkqViLMAGPUHQxFnwGySXmZIBJwucBSEknC8glIqzCjzi9rwezWVYio4lFRDgAukoIYChBM60nKCgB2/ELulJUAlTAnCEh5GbuOz1aNKrSxCUqOBlFklgXMzJhMMCX0DxmPA7M43Kj6QNaOR/zBQY5ZCUmlV4N/wANSyAFKAQewxHZBdOESmGLTegzDwUFAzfrqKqs66DadKTE6TjTZ+hUAUhBxAlMkzarCss4zWXA7JJftE4cMzRCSClI2GGWcy5MbrvdkoSAkUKiCZntEqPxMFBQvtL9YhK1FB7FpgIwDEThC3SDUYVO+gJgV44nZIWUKsSk4kpD+hAUVBZSxK2EkKLFjMSnGi04JZKK8brxkmeHsukIOAhII7KEj+kbwW34ckoWl1ALKitiHUCnCUlxTCyZMWAnBQUZLbiVgnE9kXSsoIwJBJTZ+kUU4iAUhLzzaTyiqeKWBGIWZKS2FQQCFjHhKhokGpU1QZuI1WvCEHHiJWlSgsoVhwugAADsuzJSK5bl6L4Qg4gFLS7sxT2RjxKCXSWBVPoBIACFSAHeeI2CVKT6PEpOGiUsSoLUyVKIS4FmomcpCsoYWNnZqSFJSkhQBBwiYIcZRkXwSwVidAa0ACgwZQClLLhmmVKdqvDSHQUC/ao8CfdH2jv2yPAn3R9oPHQqAB+1R4E+6PtHftkeBPuj7QeOgoAH7VHgT7o+0R+1R4Ee6PtGiOgoDP8AtUeBHuj7R37VHgR7o+0aI6CgM/7VHgR7o+0R+zs/Aj3U/aNMdBQH/9k=",
        name: "Sarees",
        Qty: 2,
        price: 550
      }
    };
  }
  incQty = () => {
    this.setState({
      Products: {
        ...this.state.Products,
        Qty: this.state.Products.Qty + 1
      }
    });
  };
  decQty = () => {
    this.setState({
      Products: {
        ...this.state.Products,
        Qty: this.state.Products.Qty - 1 > 0 ? this.state.Products.Qty - 1 : 1
      }
    });
  };

  render() {
    return (
      <Fragment>
        <div className="container">
          <div className="row">
            <div className="col">
              <table className="table">
                <thead>
                  <tr>
                    <th>SNO</th>
                    <th>Product image</th>
                    <th>PRODUCT NAME</th>
                    <th>Product Qty</th>
                    <th>Product price</th>
                    <th>product total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{this.state.Products.sno}</td>
                    <td>
                      <img src={this.state.Products.image} />
                    </td>
                    <td>{this.state.Products.name}</td>
                    <td>
                      <button onClick={this.incQty}>+</button>
                      {this.state.Products.Qty}
                      <button onClick={this.decQty}>-</button>
                    </td>
                    <td>{this.state.Products.price}</td>
                    <td>
                      {this.state.Products.Qty * this.state.Products.price}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default ProductItem;
