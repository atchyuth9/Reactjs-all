import React, { Fragment } from "react";
import Axios from "axios";
class Task1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: null,
      errorMessage: null
    };
  }
  componentDidMount() {
    Axios.get("http://localhost:8088/api/excel/books")
      .then((responce) => {
        this.setState({
          users: responce.data
        });
      })
      .catch(() => {
        this.setState({
          errorMessage: "erre"
        });
      });
  }

  render() {
    return (
      <Fragment>
        <div className="container">
          <div className="row">
            <div className="col">
              <h2>user info</h2>
              <p>user info</p>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <table className="table">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Published</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state.users ? (
                    <Fragment>
                      {this.state.users.map((user) => {
                        return (
                          <tr>
                            <td>{user.id}</td>
                            <td>{user.title}</td>
                            <td>{user.description}</td>
                            <td>{user.published}</td>
                          </tr>
                        );
                      })}
                    </Fragment>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Task1;
