import React, { Fragment } from "react";

class Ajio extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      ajio: {
        sn: 100,
        img:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPyhOXY67NSK1BRDmgowfZU88Q4NNgtvJLPQ&usqp=CAU",
        pname: "Mens-shirts",
        qty: 1,
        price: 999
      }
    };
  }
  incQty = (value) => {
    this.setState({
      ajio: {
        ...this.state.ajio,
        qty: this.state.ajio.qty + 1
      }
    });
  };
  dcQty = (value) => {
    this.setState({
      ajio: {
        ...this.state.ajio,
        qty: this.state.ajio.qty - 1 > 0 ? this.state.ajio.qty - 1 : 1
      }
    });
  };
  render() {
    return (
      <Fragment>
        <pre>{JSON.stringify(this.state.ajio)} </pre>
        <div className="container">
          <div className="rows">
            <div className="cols">
              <table class="table">
                <thead>
                  <tr>
                    <th>SNO</th>
                    <th>img</th>
                    <th>ProName</th>
                    <th>Pro Qty</th>
                    <th>price</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{this.state.ajio.sn}</td>
                    <td>
                      <img src={this.state.ajio.img} />
                    </td>
                    <td> {this.state.ajio.pname}</td>
                    <td>
                      {" "}
                      <button onClick={this.incQty} className="bt">
                        +
                      </button>
                      {this.state.ajio.qty}
                      <button onClick={this.dcQty} className="bt">
                        -
                      </button>
                    </td>
                    <td>{this.state.ajio.price}</td>
                    <td>{this.state.ajio.qty * this.state.ajio.price}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Ajio;
