import React, { Fragment } from "react";

class Event extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "achyu"
    };
  }

  changeText = (event) => {
    this.setState({
      username: event.target.value
    });
  };

  render() {
    return (
      <Fragment>
        <div className="container">
          <div className="card">
            <div className="card-body">
              <form className="form">
                <input
                  type="text"
                  value={this.state.username}
                  onChange={this.changeText}
                  className="form"
                  placeholder="username"
                />
              </form>
              <h2>{this.state.username}</h2>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Event;
