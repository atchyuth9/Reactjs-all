import React, { Fragment } from "react";

class Changeselectbox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      option: " "
    };
  }
  updateEvent = (eventt) => {
    this.setState({
      option: eventt.target.value
    });
  };
  render() {
    return (
      <Fragment>
        <div className="containerr">
          <div className="row">
            <div className="cols">
              <div className="card">
                <div className="header">
                  <p>
                    {" "}
                    <h2>Change select box</h2>
                  </p>
                </div>
                <div className="card-body">
                  <div className="r">
                    <form>
                      <div className="formgrp">
                        <select onChange={this.updateEvent} className="optns">
                          <option value=""> select a technology</option>
                          <option value="react js">ReactJs</option>
                          <option value="node js">NodeJs</option>
                          <option value="core java">CoreJava</option>
                          <option value="Springboot">Springboot</option>
                        </select>
                      </div>
                    </form>
                  </div>
                  <div className="c1">
                    <p>
                      <h2>{this.state.option}</h2>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Changeselectbox;
