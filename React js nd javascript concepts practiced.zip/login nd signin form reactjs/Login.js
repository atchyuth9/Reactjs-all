import React, { useState } from "react";

const Login = () => {
  const [data, setData] = useState({
    UserName: "",
    PassWord: ""
  });
  const { UserName, PassWord } = data;

  const change = (e) => {
    setData({ ...data, [e.target.name]: [e.target.value] });
  };
  const submithandler = (c) => {
    c.preventDefault();
    console.log(data);
  };
  return (
    <div>
      <form onSubmit={submithandler}>
        <input
          type="text"
          placeholder="username"
          name="UserName"
          value={UserName}
          onChange={change}
        />
        <br />
        <input
          type="password"
          placeholder="password"
          name="PassWord"
          value={PassWord}
          onChange={change}
        />
        <br />
        <input type="submit" name="submit" />
      </form>
    </div>
  );
};

export default Login;
