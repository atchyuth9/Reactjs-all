import React, { useState } from "react";
import styles from "./styles.css";
const Task = () => {
  const [data, setData] = useState({
    UserName: "",
    PhoneNum: "",
    Email: "",
    PassWord: "",
    ConfirmPassWord: ""
  });
  const { UserName, PhoneNum, Email, PassWord, ConfirmPassWord } = data;
  const change = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };
  const subhand = (s) => {
    s.preventDefault();
    if (UserName.length <= 5) {
      alert("username must be 5 chacracters");
    } else if (PassWord !== ConfirmPassWord) {
      alert("passwords not matched");
    } else {
      console.log(data);
    }
  };

  return (
    <div>
      <form onSubmit={subhand}>
        <input
          type="text"
          placeholder="Enter your nanme"
          name="UserName"
          value={UserName}
          onChange={change}
        />
        <br />
        <input
          type="text"
          placeholder="Enter Phone num"
          name="PhoneNum"
          value={PhoneNum}
          onChange={change}
        />
        <br />
        <input
          type="email"
          placeholder="Enter your mail"
          name="Email"
          value={Email}
          onChange={change}
        />
        <br />
        <input
          type="password"
          placeholder="Enter your password"
          name="PassWord"
          value={PassWord}
          onChange={change}
        />
        <br />
        <input
          type="password"
          placeholder="Confirm Password"
          name="ConfirmPassWord"
          value={ConfirmPassWord}
          onChange={change}
        />
        <br />
        {PassWord !== ConfirmPassWord ? (
          <p className="p">Passwords not matched</p>
        ) : null}
        <input type="submit" name="submit" />
      </form>
    </div>
  );
};

export default Task;
