import React from "react";
import CompanyProp from "./CompanyProp";
import Name from "./Name.js";
class Cls extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "achyu",
      company: "virtusa",
      salary: 700000,
      location: "hyderabad"
    };
  }
  changeComp() {
    this.setState({
      salary: this.state.salary + 100000
    });
  }
  render() {
    return (
      <div>
        <h2>{this.state.name}</h2>
        <CompanyProp companyProp={this.state.company} />
        <Name names={this.state.salary} />
        <h2>{this.state.location}</h2>
        <button type="button" onClick={this.changeComp.bind(this, "delhi")}>
          loc
        </button>
      </div>
    );
  }
}
export default Cls;
