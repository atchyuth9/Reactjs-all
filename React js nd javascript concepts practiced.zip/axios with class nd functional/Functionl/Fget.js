import React, { useEffect, useState } from "react";
import axios from "axios";
let Fget = () => {
  const [Data, setData] = useState([]);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        console.log(response);
        setData(response.data);
      })
      .catch((error) => {
        console.log("nodata", error);
      });
  });

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>id</th>
            <th>name</th>
            <th>username</th>
            <th>email</th>
          </tr>
          <tbody>
            {Data.map((data) => {
              return (
                <tr key={data.id}>
                  <td>{data.id}</td>
                  <td>{data.name}</td>
                  <td>{data.username}</td>
                  <td>{data.email}</td>
                </tr>
              );
            })}
          </tbody>
        </thead>
      </table>
    </div>
  );
};

export default Fget;
