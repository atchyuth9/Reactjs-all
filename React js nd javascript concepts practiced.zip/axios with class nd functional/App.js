import "./styles.css";
import Cls from "./Cls.js";
import Api from "./Api";
import Fun from "./Fun";
import Form from "./Form";
import List from "./List.js";
import Get from "./Get";
import Axi from "./Axi";
import Postapi from "./Postapi";
import Delete from "./Delete";
import Fget from "./Functionl/Fget";
import FPost from "./Functionl/FPost";

export default function App() {
  return (
    <div className="App">
      {/* <Get />
      <br />
      <Axi />
      <br />
      <Postapi />
      <br />
      <Delete />
      <br />
      <Fget />
     <br />*/}
      <FPost />
    </div>
  );
}
