import React from "react";
import axios from "axios";
class Get extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: []
    };
  }

  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((responce) => {
        this.setState({
          list: responce.data
        });
      })
      .catch(() => {
        this.setState({
          errorMessage: "err"
        });
      });
  }

  render() {
    return (
      <div>
        <pre>{JSON.stringify(this.state.list)}</pre>
        <ul>
          {this.state.list.map((lis) => {
            <li>{lis.name}</li>;
          })}
        </ul>
      </div>
    );
  }
}

export default Get;
