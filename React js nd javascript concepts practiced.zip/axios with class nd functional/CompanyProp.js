import React from "react";

class CompanyProp extends React.Component {
  render() {
    return (
      <div>
        <h2>props:{this.props.companyProp}</h2>
      </div>
    );
  }
}
export default CompanyProp;
