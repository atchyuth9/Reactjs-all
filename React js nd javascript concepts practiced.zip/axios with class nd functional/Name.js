import React from "react";
class Name extends React.Component {
  render() {
    return (
      <div>
        <h2>{this.props.names}</h2>
      </div>
    );
  }
}

export default Name;
