import React, { useEffect, useState } from "react";
const List = () => {
  const [count, setCount] = useState(0);
  const [resetcounter, setresetCounter] = useState(true);
  const inc = () => {
    setCount(count + 1);
  };
  const reset = () => {
    setresetCounter(!resetcounter);
  };
  useEffect(() => {
    if (count > 0) {
      setCount(0);
    }
  }, [resetcounter]);
  return (
    <div>
      count: {count}
      <br />
      <button onClick={inc}>Click</button>
      <br />
      <button onClick={reset}>clicktoreset</button>
      <br />
    </div>
  );
};
export default List;
