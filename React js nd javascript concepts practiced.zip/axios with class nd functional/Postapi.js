import React from "react";
import axios from "axios";
class Postapi extends React.Component {
  state = {
    username: []
  };
  handle = (e) => {
    this.setState({
      username: e.target.value
    });
  };
  sub = (event) => {
    event.preventDefault();
    const post = {
      username: this.state.username
    };
    axios
      .post("https://jsonplaceholder.typicode.com/users", { post })
      .then((response) => {
        console.log(response);
        console.log(response.data);
      });
  };

  render() {
    return (
      <div>
        <form onSubmit={this.sub}>
          <div>
            <label>
              Post Title:
              <input
                type="text"
                onChange={this.handle}
                name="username"
                placeholder="enter ur name"
              />
            </label>
            <br />
            <button type="submit">Add</button>
          </div>
        </form>
      </div>
    );
  }
}

export default Postapi;
