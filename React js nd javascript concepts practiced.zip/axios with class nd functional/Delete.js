import React from "react";
import axios from "axios";
class Delete extends React.Component {
  state = {
    id: ""
  };
  changee = (e) => {
    this.setState({
      id: e.target.value
    });
  };
  subm = (event) => {
    event.preventDefault();
    axios
      .delete("https://jsonplaceholder.typicode.com/users/${this.state.id}")
      .then((response) => {
        console.log(response);
        console.log(response.data);
      })
      .catch((error) => {
        errorMsg: "err";
      });
  };
  render() {
    return (
      <div>
        <form onSubmit={this.subm}>
          <input
            type="text"
            placeholder="enterid"
            name="id"
            onChange={this.changee}
          />
          <button type="submit">delete</button>
        </form>
      </div>
    );
  }
}

export default Delete;
