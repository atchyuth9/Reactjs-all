import React from "react";
const Parent = () => {
  return (
    <div>
      <h1>This is Parent Component</h1>
    </div>
  );
};
export default Parent;
