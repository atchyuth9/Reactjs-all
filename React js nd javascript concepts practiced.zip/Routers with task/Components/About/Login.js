import React, { useState } from "react";
import { Navigate } from "react-router";
function Login() {
  const [data, setData] = useState({
    UserName: "",
    PassWord: "",
  });
  const { UserName, PassWord } = data;
  const change = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };
  const submithandler = (c) => {
    c.preventDefault();
    console.log(data);
  };
  const [auth, setAuth] = useState(false);
  if (auth) {
    return <Navigate to="/euc" />;
  }
  return (
    <div>
      <center>
        <h2>Enter Login Details</h2>
        <form onSubmit={submithandler}>
          <input
            type="text"
            placeholder="username"
            name="UserName"
            value={UserName}
            onChange={change}
          />
          <br />
          <input
            type="password"
            placeholder="password"
            name="PassWord"
            value={PassWord}
            onChange={change}
          />
          <br />

          <input onClick={() => setAuth(true)} type="submit" name="submit" />
        </form>
      </center>
    </div>
  );
}

export default Login;
