import React from "react";
class Employee extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      Emp: {
        CompanyName: "Virtusa",
        EmpName: "achyuth Brundavanam",
        Role: "Associate Engineer Technology",
        Location: "Hyderabad",
        Sal: 400000,
      },
    };
  }
  render() {
    let { CompanyName, EmpName, Role, Location, Sal } = this.state.Emp;
    return (
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-3">
            <div className="card">
              <img
                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVkAAACSCAMAAADYdEkqAAAAYFBMVEX///+Gg4F8eXd/fHqDgH719fWbmZf8/Pzx8fH4+Pjc29vV1NPp6OjFw8KIhYN7d3WRjoy2tbTKyci8u7rj4uKopqWioJ6wrq26ubiXlZPm5eXY19aOi4nIx8ZybmzBv79NohLMAAAIvElEQVR4nO2cC5ezKAyGR0DtxYraattpZ/r//+V6qSRAtKNtndndPOfsOfs5IPCKIYTYjw+GYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiG6VkbptSK51X7PxF+iw79PUWjS19NfMdv69u/m1AEHeo8pdpG3qsFgpWlMcrKrynVWNmHGGVFOKUaK/uQXll1nFSNlX1Ir6yctsazsg+5K6u306qxsg/plJXTbAEr+wNaZWU5tRor+5BGWZ1PrsbKPiTUUl2mV2NlHxLq/RxpWNmHxPOEOYCyL+tKeNmXUZZlUXnbjPuA4ebWlazy4rDMk83P0Z0z2WACfy9+dsdwuy+rrkY32nt11SurIkPVVdmYRjJPoOH2v85Cqh4phvu3dkrKaqLHOIut6FsUZHMn0yW96q6Eo8ZgG2lTQ3QyBd2/AoMZpLq6ndDejtncTe6s6zcp0S2bu0p5onoUHrVTsik6y6JNw7ykqqL+nJo/Z31Pv9WOKtlwuAo0iPsuLQ2G6O+5BUvhK2vuhltNrpK4n1T+7LgJRZSsi25+qtBcjqZhTTzGRJiu9AOrvS6Z0cGYo7B7/zZlD5qUq67vTI8wo55AN1xyhr+QDWhHmIOTGYEZc+PPKvXpl43Pzijepmyih295XaHKKzXwBNq2pjvl04CVhTAHqf/HbncrEq9s5o7ibcqmI3opCT1buQbWkXbQqr2G3LTuR68+iQl9j8got3DljeJdyu4H3/AWswrGYzO2LelPj1eSjJiDE2GEe2WdGV4Ir+NvUjZGwtY+VI01NcW+r+o8a8dDCaaeN03nahryzAEYA4jA9PFZYW1x17awnQvVKasGvS7Ze12TlC1AWZkVyXq92uzBJ4Eg3Oobd0ik5em2L1PLVRCHF+g3zG1w34mmM/go5kzhiouecIeVzo55nh+72+UtJdjz3HCfXtOUhTsJ2Bxs7k6ARLMDFmcl8n5hS0o0B9TkkN0kVoPmAEywgotwDoY9Qmz6xIlwysZ2t9OUhXdsjwvumn6pCF/6vJsJWeFFYYNdblqSV2E2nq45AGOAHBQ4FUfB7wtWllwXxiIy05QdcsA3GrYzdzqvS+ydqzBr32wOwHDZ3gEYA4Hc1xDeMbgI+41AYocSeIOy7uQ/6NS9dVg7aNIRFrc37WR/MvGAOQDbmeLOgt6gIfiy1H6j4R3Kus+w8B9qfJWEm266q968W6hocwAGDW8EQ2pZgylrrWuI1ykLNipyCxPE1E78q7/rm5cwPDJkDhJqclrKwvQ0283BaM3rlAU3VUW05XmIGRodhnoh0H30LhtjYK8LlLJrah7bvE7ZL1gtlaiKOfsos4b9aNo/w5EyB+ats838uLJEPKHjdcqucDymCWRHu8fHBMml2O1uu2LTzvLllAWfGoaNjIE13F9X1otQKCVEdhr2n5L9uda/RtX/6SD6SsLFlP0glnYwBnbrv6/syt5J9+oGORk1Luqdr/Uo6mk+bRF8ipNvDsAY2AdMv68sFf1p+y6OXrRuk45GEt+vLIoQxO4VbRf9A8p+nGhp6+noHDMeh2PkCykLvmsvF8xix+X7C8p+3AakDYTV22o8kruIsibg1ZsDkNrxo/6Esh+HdEA0nHFWPhJ2CWVhVejiHGAMlFPybyhbu7WKtqAQJtg6psANfC+jLGylO71Ogzvrv6JsXa3yMglwF2IcbJdCZdE5C5wDiCWU/bLNgfEMvDjb31G2yccpA+HlaVTOiNqzh/s+OE6KUgm0P/6JNs+xNq9O4x2AMQi80fwhZRuS7TF1TsI6FSH+JhyP4VAO+OrvocLmAIyBF9x8Wlk/YwSp7oZYUIRzJK8sLCJ0vtU9A9gE+3lVC+7BPtDEad4mMAZeNOn5OevNS+RNu7aHPIqjSFBKXmsOzDEHod5ycYMWdFAFUbbMKzZTWXQO5hWJwRLdnD9t6elM5XSCtG2MeNfXJGLxCytrAl7ysjf/6xu3mcqipBA/Yxxi7G4GAArGoqtx6hkp/OzaouZ41HsPFlfWvK+qzIxQfpBjprLgMBMnJChtz04YCyGkjuKb8VUJ/wBrbbvgoKxvRpa1szjDKxhpeKayaxSv9pYwOPp1Ji1MWbSAxc2q7x7Iev5MPuiRI0uxkLK553ZT6/FMZdFRmfLTy9HCjj80Qxlc4KvFnTtlJxHg7ndygTvrpqCtK5jdyygLprCHSqmdq2yEpFX5JVmFq8RYQJRiI6PeAq3Rvh8lN/QrlZI73D0079sDUXBG1BWXW9+Q87uQsrCQ9O1SJ5tzlb1Zu8o2002b0/YQPdTmcOuQHLZHnIJlPIMYJZNKedx0jyE+lBAk6LaN4AnXT7K4T9t602YlNS+lLGR43XtOffc1V9mDH/hDPp2Vualkc7qCFZDGVubWbeonFGTn7GqVvj8vfKgjRVYdy3PqboWXUtY9BnHDXC1zlfXeCNtb9vKarYIoi+HsFXRCWP2W66DtQkSoazFlneHRv2AwW9mtN2mxstThlkGjXULtco2UxN6Fnyv9e8oWljkQxMcITyiL1zBfWcpamJtavn4cjQW0FXgC68Fyi8a6ur7YoyPLzFc2dt94e+98GDgLVN4mKh/5AkSh6Z0MPCyxbKyrBb9AfpirZb6y9WyzP85yohL0J0Yy81OMNoNnNWc7m5L6UkGJrenvcspuUY8HRHpC2drpzPDq7MV7dtJVTA6EZXfEWU19yd3zriv3yzGlq3DpuEGLFoaBrMIQftJsS1x7lGaV7CrVF9ap+9f4FkDeReNS7Qbzior2O1QjWF04oyK4B3SkUxfSx6aDK/Nrbm/+BgQRrgwDX1/HUAJGTV0bbSWpWYVU4c99lEottEyrHbmEGtbbvC4qtBYyOB+J5Nl7Y0V5lVrrulB+cccw6Zex/gM0P6L4w0+O299bfFh2wg0ZhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEW5h89Zl/VNvz04gAAAABJRU5ErkJggg=="
                alt="turn on the data"
              />
              <div className="card-body">
                <span> Company Name: {CompanyName} </span> <br />
                <span>Employe Name: {EmpName}</span>
                <br />
                <span>Emplnoye Role: {Role}</span>
                <br />
                <span>Employe Location: {Location}</span>
                <br />
                <span>Salary: {Sal}</span>
                <br />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Employee;
