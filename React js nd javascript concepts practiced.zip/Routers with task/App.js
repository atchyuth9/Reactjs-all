import React from "react";
import Task from "./Task.js";
import Navbar from "./Components/Navbarr/Navbar.js";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./Components/Home/Home.js";
import Employee from "./Components/Employe/Employee.js";
import Euc from "./Components/Euc/Euc.js";
import Login from "./Components/About/Login.js";
import index from "./index.css";
function App() {
  return (
    <React.Fragment>
      <div className="App">
        <Router>
          <Navbar />
          <Routes>
            <Route exact path="/home" element={<Home />} />
            <Route exact path="/login" element={<Login />} />
            <Route exact path="/euc" element={<Euc />} />
            <Route exact path="/employe" element={<Employee />} />
          </Routes>
        </Router>
      </div>
    </React.Fragment>
  );
}
export default App;
