import React, { Fragment } from "react";
import axios from "axios";
class Task extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      books: null,
      errorMessage: null,
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:8088/api/excel/books")
      .then((responce) => {
        this.setState({
          books: responce.data,
        });
      })
      .catch(() => {
        this.setState({
          errorMessage: "err",
        });
      });
  }

  render() {
    return (
      <Fragment>
        <div className="container">
          <div className="row">
            <div className="col">
              <pre>{JSON.stringify(this.state.books)}</pre>
              <table className="table">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Description</th>
                  </tr>
                </thead>

                <tbody>
                  {this.state.books ? (
                    <Fragment>
                      {this.state.books.map((book) => {
                        return (
                          <tr key={book.id}>
                            <td>{book.id}</td>
                            <td>{book.title}</td>
                            <td>{book.description}</td>
                          </tr>
                        );
                      })}
                    </Fragment>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Task;
