import axios from "axios";
import React, { Fragment } from "react";
import Task from "./Task.js";

class Books extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      books: [],
    };
  }
  componentDidMount() {
    Task.getBooks().(response {
      this.setState({ books: response.data });
    });
  }

  render() {
    return (
      <Fragment>
        <h1 className="text">BooksList</h1>
        <table className="table">
          <thead>
            <tr>
              <td>Id</td>
              <td>Title</td>
              <td>Description</td>
              <td>Published</td>
            </tr>
          </thead>
          <tbody>
            {this.state.users ? (
              <Fragment>
                {this.state.books.map((book) => {
                  return (
                    <tr>
                      <td>{book.id}</td>
                      <td>{book.title}</td>
                      <td>{book.description}</td>
                      <td>{book.published}</td>
                    </tr>
                  );
                })}
              </Fragment>
            ) : null}
          </tbody>
        </table>
      </Fragment>
    );
  }
}

export default Books;
